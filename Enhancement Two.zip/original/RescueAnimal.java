

import java.lang.String;

public class RescueAnimal {

    // Instance variables
    public String name;
    public String animalType;
    public String gender;
    public String age;
    public String weight;
    public String acquisitionDate;
    public String acquisitionCountry;
    public String trainingStatus;
    public boolean reserved;
    public String inServiceCountry;


    // Constructor
    public RescueAnimal() {
    }

//Accessors and mutators

    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getAnimalType() {
        return animalType;
    }


    public void setAnimalType(String animalType) {
        this.animalType = animalType;
    }


    public String getGender() {
        return gender;
    }


    public void setGender(String gender) {
        this.gender = gender;
    }


    public String getAge() {
        return age;
    }


    public void setAge(String age) {
        this.age = age;
    }


    public String getWeight() {
        return weight;
    }


    public void setWeight(String weight) {
        this.weight = weight;
    }


    public String getAcquisitionDate() {
        return acquisitionDate;
    }


    public void setAcquisitionDate(String acquisitionDate) {
        this.acquisitionDate = acquisitionDate;
    }


    public String getAcquisitionLocation() {
        return acquisitionCountry;
    }


    public void setAcquisitionLocation(String acquisitionCountry) {
        this.acquisitionCountry = acquisitionCountry;
    }


    public boolean getReserved() {
        return reserved;
    }


    public void setReserved(boolean reserved) {
        this.reserved = reserved;
    }


    public String getInServiceLocation() {
        return inServiceCountry;
    }


    public void setInServiceCountry(String inServiceCountry) {
        this.inServiceCountry = inServiceCountry;
    }




    public String getTrainingStatus() {
        return trainingStatus;
    }


    public void setTrainingStatus(String trainingStatus) {
        this.trainingStatus = trainingStatus;
    }
}
