
public class Monkey extends RescueAnimal{  //Initialization of specified variables
    private String species;
    private String breed;
    private double tailLength;
    private double height;
    private double bodyLength;

    enum Species{Capuchin, Guenon, Macaque, marmoset, SquirrelMonkey, Tamarin}  //Monkey species


    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }

    public Monkey() {  // Initial values for field variables
        species = "";
        breed = "";
        tailLength = 0.0;
        height = 0.0;
        bodyLength = 0.0;
    }

    public Monkey(String monkSpecies, String monkBreed, double monkTailLength, double monkHeight, double
            monkBodyLength, String name, String gender, String age, String weight, String acquisitionDate, String
                          acquisitionCountry, String trainingStatus, boolean reserved, String inServiceCountry) {
        this.species = monkSpecies;
        this.breed = monkBreed;
        this.tailLength = monkTailLength;
        this.height = monkHeight;
        this.bodyLength = monkBodyLength;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.weight = weight;
        this.acquisitionDate = acquisitionDate;
        this.acquisitionCountry = acquisitionCountry;
        this.trainingStatus = trainingStatus;
        this.reserved = reserved;
        this.inServiceCountry = inServiceCountry;
    }

// Accessors and mutators for variables in monkey class

    String getSpecies() {
        return species;
    }
    String getBreed() {
        return breed;
    }
    double getTailLength() {
        return tailLength;
    }
    double getHeight() {
        return height;
    }
    double getBodyLength() {
        return bodyLength;
    }

    void setSpecies(String monkSpecies) {
        this.species = monkSpecies;
    }
    void setBreed(String monkBreed) {
        this.breed = monkBreed;
    }
    void setTailLength(double monkTailLength) {
        this.tailLength = monkTailLength;
    }
    void setHeight(double monkHeight) {
        this.height = monkHeight;
    }
    void setBodyLength(double monkBodyLength) {
        this.bodyLength = monkBodyLength;
    }
}
