# Rescue Animal System — Database Enhancement

## What's in this zip

- `original/` — the four original, unmodified source files.
- `enhanced/` — the database-backed version:
  - `IRescueAnimal.java`, `RescueAnimal.java`, `Dog.java`, `Monkey.java` — the object model,
    carrying forward the software-design fixes (private fields, corrected `Monkey` constructor,
    the shared interface) from the previous enhancement.
  - `schema.sql` — the normalized SQL schema (an `animals` base table with `dogs` and `monkeys`
    child tables), plus seed data matching the original hard-coded sample animals.
  - `rescue_animals.db` — a SQLite database already built from `schema.sql`, ready to use.
  - `DBConnection.java` — the single class holding the JDBC connection string.
  - `RescueAnimalDao.java` — the only class containing SQL; `save`, `findAllDogs`,
    `findAllMonkeys`, `existsByName`, `reserveByTypeAndCountry`, and
    `findInServiceAndUnreserved`, all using parameterized `PreparedStatement`s.
  - `Driver.java` — now calls the DAO instead of holding `dogList`/`monkeyList` in memory.

## Why SQLite

SQLite was chosen as a lightweight, file-based, zero-configuration engine appropriate for a
project at this scale — no separate database server has to be installed or running for the
grader to try this out. The design (schema in its own file, a DAO layer, parameterized queries)
does not depend on SQLite specifically; pointing `DBConnection` at a MySQL or PostgreSQL JDBC URL
instead is the only change a different engine would require.

## Dependencies

This needs a SQLite JDBC driver on the classpath (tested with Xerial's `sqlite-jdbc`, which also
requires `slf4j-api` at runtime). On a Debian/Ubuntu system these are available as:

```
sudo apt-get install sqlite3 libxerial-sqlite-jdbc-java
```

which installs the driver to `/usr/share/java/sqlite-jdbc.jar` and slf4j to
`/usr/share/java/slf4j-api.jar` (a no-op logging backend, `slf4j-nop.jar`, avoids startup warnings).

If you're using an IDE (IntelliJ, Eclipse) instead, just add the Xerial `sqlite-jdbc` jar (and
`slf4j-api`) as a project dependency/library instead of using the classpath commands below.

## Building and running

From inside `enhanced/`:

```
javac -cp "/usr/share/java/sqlite-jdbc.jar:/usr/share/java/slf4j-api.jar:/usr/share/java/slf4j-nop.jar" *.java

java -Djava.library.path=/usr/lib/x86_64-linux-gnu/jni \
     -cp ".:/usr/share/java/sqlite-jdbc.jar:/usr/share/java/slf4j-api.jar:/usr/share/java/slf4j-nop.jar" \
     Driver
```

(The `-Djava.library.path` flag is only needed on Linux with the Debian-packaged driver, which
ships its native library separately; the plain Maven-distributed `sqlite-jdbc` jar bundles its
native libraries internally and doesn't need this flag.)

`rescue_animals.db` already contains the same six sample animals the original code seeded in
memory. Run the program, choose option 4 or 5 to see them, intake a new animal, quit, and run the
program again — the new animal is still there, which is the actual point of this enhancement:
data now survives after the program exits.

## Rebuilding the database from scratch

```
sqlite3 rescue_animals.db < schema.sql
```

This drops and recreates all three tables and re-seeds the sample data.
