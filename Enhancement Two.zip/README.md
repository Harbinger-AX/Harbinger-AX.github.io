# Rescue Animal System — Algorithms and Data Structures Enhancement

## What changed in this milestone

This enhancement builds on the already-completed software design and databases enhancements
(the object model and the DAO/schema were already in place). The specific algorithms and data
structures improvement made here is in `RescueAnimalDao.java`:

- **`findInServiceAndUnreserved()` now filters in SQL instead of in Java.** The previous version
  called `findAllDogs()` and `findAllMonkeys()` — fetching every row in the table — and then
  discarded most of them in Java with `removeIf`. This version uses a single `UNION ALL` query
  with the filter (`training_status = 'in service' AND reserved = 0`) in the SQL `WHERE` clause,
  so the database only returns rows that actually qualify.
- **A composite index, `idx_animals_status_reserved`, was added** on
  `(training_status, reserved)` in `schema.sql` — exactly the two columns the query above filters
  on. `EXPLAIN QUERY PLAN` confirms SQLite uses this index (`SEARCH ... USING INDEX
  idx_animals_status_reserved`) rather than a full table scan.
- **`reserveByTypeAndCountry()` now orders candidates by `id`** so which animal gets reserved,
  when more than one unreserved match exists, is deterministic rather than dependent on
  unspecified row order.

## A note on the original plan

The enhancement plan for this category, written before the database enhancement existed, called
for consolidating `Driver`'s two `ArrayList`s (`dogList`, `monkeyList`) into a single
`ArrayList<RescueAnimal>`, and for making sure `reserveAnimal` checked an animal's existing
reserved status before reserving it again. Because the database enhancement was completed first
(out of the original category order), `Driver` no longer holds those lists at all — the
equivalent design smell (two parallel fetches recombined afterward) had moved into the DAO layer
instead, which is what this enhancement actually addresses. Separately, the duplicate-reservation
check turned out to already be satisfied: the original `reserveByTypeAndCountry` query already
included `AND reserved = 0`, since that fell out naturally from writing the lookup as a SQL
`WHERE` clause rather than as a loop over an in-memory list.

## Building and running

Same as the databases enhancement:

```
javac -cp "/usr/share/java/sqlite-jdbc.jar:/usr/share/java/slf4j-api.jar:/usr/share/java/slf4j-nop.jar" *.java

java -Djava.library.path=/usr/lib/x86_64-linux-gnu/jni \
     -cp ".:/usr/share/java/sqlite-jdbc.jar:/usr/share/java/slf4j-api.jar:/usr/share/java/slf4j-nop.jar" \
     Driver
```

To see the query plan directly:

```
sqlite3 rescue_animals.db "EXPLAIN QUERY PLAN SELECT ... "
```
(see `RescueAnimalDao.findInServiceAndUnreserved()` for the exact query.)
