import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Centralizes the connection to the rescue animal database.
 *
 * This is the only class that knows the database's location and connection string; every other
 * class that needs data goes through {@link RescueAnimalDao}, not through this class directly.
 * That keeps the JDBC connection details in exactly one place instead of scattered across every
 * class that happens to need data.
 *
 * The database itself (rescue_animals.db, built from schema.sql) is a SQLite file completely
 * independent of this Java application — it can be opened, backed up, or migrated to a different
 * engine (MySQL, PostgreSQL) without any of the classes above the DAO layer needing to change,
 * since they only depend on the RescueAnimalDao interface's method signatures, not on how it
 * talks to the database.
 */
public final class DBConnection {

    // Points at the SQLite file built from schema.sql. In a deployment against a client-server
    // database instead of an embedded file, only this URL (and the driver on the classpath)
    // would need to change.
    private static final String DB_URL = "jdbc:sqlite:rescue_animals.db";

    private DBConnection() {
        // Utility class; not meant to be instantiated.
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }
}
