-- Rescue Animal System — database schema
--
-- Normalized to match the object model: shared RescueAnimal fields live in `animals`;
-- Dog-specific and Monkey-specific fields live in their own child tables, each linked back
-- to `animals` by a foreign key. This avoids a single flat table where most columns would be
-- null for any given row, and keeps this schema independent of the Java application — nothing
-- here references Java types, and nothing in the Java code assumes this specific engine.

DROP TABLE IF EXISTS monkeys;
DROP TABLE IF EXISTS dogs;
DROP TABLE IF EXISTS animals;

CREATE TABLE animals (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    name                  TEXT    NOT NULL,
    animal_type           TEXT    NOT NULL,               -- 'Dog' or 'Monkey'
    gender                TEXT,
    age                   TEXT,
    weight                TEXT,
    acquisition_date      TEXT,
    acquisition_country   TEXT,
    training_status       TEXT,
    reserved              INTEGER NOT NULL DEFAULT 0,      -- 0 = false, 1 = true
    in_service_country    TEXT
);

CREATE TABLE dogs (
    animal_id             INTEGER PRIMARY KEY,
    breed                 TEXT,
    FOREIGN KEY (animal_id) REFERENCES animals(id) ON DELETE CASCADE
);

CREATE TABLE monkeys (
    animal_id             INTEGER PRIMARY KEY,
    species               TEXT,
    breed                 TEXT,
    tail_length           REAL,
    height                REAL,
    body_length           REAL,
    FOREIGN KEY (animal_id) REFERENCES animals(id) ON DELETE CASCADE
);

CREATE INDEX idx_animals_name ON animals(name);
CREATE INDEX idx_animals_type ON animals(animal_type);
CREATE INDEX idx_animals_acquisition_country ON animals(acquisition_country);
CREATE INDEX idx_animals_status_reserved ON animals(training_status, reserved);

-- Sample seed data, matching the values Driver previously hard-coded in
-- initializeDogList()/initializeMonkeyList(), now living in the database instead of in Java.
INSERT INTO animals (name, animal_type, gender, age, weight, acquisition_date, acquisition_country, training_status, reserved, in_service_country)
VALUES
    ('Spot',    'Dog', 'male',   '1', '25.6', '05-12-2019', 'United States', 'intake',      0, 'United States'),
    ('Rex',     'Dog', 'male',   '3', '35.2', '02-03-2020', 'United States', 'Phase I',     0, 'United States'),
    ('Bella',   'Dog', 'female', '4', '25.6', '12-12-2019', 'Canada',        'in service',  1, 'Canada'),
    ('Albert',  'Monkey', 'male',   '8', '9.5', '06-12-2019', 'Costa Rica', 'in service', 0, 'United States'),
    ('Ada',     'Monkey', 'female', '6', '1.2', '04-18-2020', 'Brazil',     'Phase 4',    1, 'Canada'),
    ('Galileo', 'Monkey', 'male',   '7', '7.8', '11-22-2019', 'Congo',      'Phase 3',    0, 'United States');

INSERT INTO dogs (animal_id, breed)
SELECT id, CASE name
    WHEN 'Spot'  THEN 'German Shepherd'
    WHEN 'Rex'   THEN 'Great Dane'
    WHEN 'Bella' THEN 'Chihuahua'
END
FROM animals WHERE animal_type = 'Dog';

INSERT INTO monkeys (animal_id, species, breed, tail_length, height, body_length)
SELECT id,
    CASE name WHEN 'Albert' THEN 'Capuchin' WHEN 'Ada' THEN 'Tamarin' WHEN 'Galileo' THEN 'Guenon' END,
    'N/A',
    CASE name WHEN 'Albert' THEN 17.6 WHEN 'Ada' THEN 13.2 WHEN 'Galileo' THEN 26.2 END,
    CASE name WHEN 'Albert' THEN 18.4 WHEN 'Ada' THEN 10.1 WHEN 'Galileo' THEN 20.3 END,
    CASE name WHEN 'Albert' THEN 18.1 WHEN 'Ada' THEN 9.9  WHEN 'Galileo' THEN 21.2 END
FROM animals WHERE animal_type = 'Monkey';
