/**
 * Represents a rescue monkey.
 *
 * Enhancements made to the original version:
 *  - The parameterized constructor's parameter list has been corrected. In the original code,
 *    the constructor expected (species, breed, tailLength, height, bodyLength, name, gender, ...)
 *    with the last three as {@code double}, but neither call site in {@code Driver} matched that
 *    order or those types — both passed the shared fields first and passed every value, including
 *    the numeric measurements, as {@code String}. This constructor now matches how the animal is
 *    actually built: shared fields first (matching {@code RescueAnimal}'s constructor), then the
 *    monkey-specific fields, with the three measurements taken as {@code double} and validated by
 *    the caller before this constructor is invoked.
 *  - The stray, unused {@code public static void main} stub has been removed — it had no
 *    relationship to {@code Driver.main}, which is the application's actual entry point.
 *  - The species enum's constant names have been changed to standard upper-case naming
 *    (e.g., {@code SQUIRREL_MONKEY} instead of {@code SquirrelMonkey}) to follow Java convention.
 *  - Accessors and mutators are now consistently {@code public}, matching {@code RescueAnimal}'s
 *    visibility instead of the original's unmodified (package-private) methods.
 *  - Added a {@code toString()} override so printing a monkey produces readable output.
 */
public class Monkey extends RescueAnimal {

    private String species;
    private String breed;
    private double tailLength;
    private double height;
    private double bodyLength;

    /** Monkey species supported by the system. */
    public enum Species {
        CAPUCHIN, GUENON, MACAQUE, MARMOSET, SQUIRREL_MONKEY, TAMARIN
    }

    public Monkey() {
        super();
        species = "";
        breed = "";
        tailLength = 0.0;
        height = 0.0;
        bodyLength = 0.0;
    }

    public Monkey(String name, String gender, String age, String weight, String acquisitionDate,
                  String acquisitionCountry, String trainingStatus, boolean reserved, String inServiceCountry,
                  String species, String breed, double tailLength, double height, double bodyLength) {
        super(name, "Monkey", gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus,
                reserved, inServiceCountry);
        this.species = species;
        this.breed = breed;
        this.tailLength = tailLength;
        this.height = height;
        this.bodyLength = bodyLength;
    }

    // Accessors and mutators for the fields specific to Monkey

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public double getTailLength() {
        return tailLength;
    }

    public void setTailLength(double tailLength) {
        this.tailLength = tailLength;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getBodyLength() {
        return bodyLength;
    }

    public void setBodyLength(double bodyLength) {
        this.bodyLength = bodyLength;
    }

    @Override
    public String toString() {
        return "Monkey{name=" + getName() + ", species=" + species + ", breed=" + breed
                + ", tailLength=" + tailLength + ", height=" + height + ", bodyLength=" + bodyLength
                + ", gender=" + getGender() + ", age=" + getAge() + ", weight=" + getWeight()
                + ", acquisitionDate=" + getAcquisitionDate()
                + ", acquisitionCountry=" + getAcquisitionLocation()
                + ", trainingStatus=" + getTrainingStatus()
                + ", reserved=" + getReserved()
                + ", inServiceCountry=" + getInServiceLocation() + "}";
    }
}
