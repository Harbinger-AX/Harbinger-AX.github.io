/**
 * Represents a rescue dog.
 *
 * Enhancements made to the original version:
 *  - The shared fields are now set through {@code RescueAnimal}'s protected constructor instead
 *    of being duplicated here.
 *  - Added a {@code toString()} override so printing a dog (e.g., {@code System.out.println(dogList)})
 *    produces readable output instead of the default {@code Dog@<hashcode>}.
 */
public class Dog extends RescueAnimal {

    private String breed;

    public Dog() {
        super();
        breed = "";
    }

    public Dog(String name, String breed, String gender, String age, String weight, String acquisitionDate,
               String acquisitionCountry, String trainingStatus, boolean reserved, String inServiceCountry) {
        super(name, "Dog", gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus,
                reserved, inServiceCountry);
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    @Override
    public String toString() {
        return "Dog{name=" + getName() + ", breed=" + breed + ", gender=" + getGender()
                + ", age=" + getAge() + ", weight=" + getWeight()
                + ", acquisitionDate=" + getAcquisitionDate()
                + ", acquisitionCountry=" + getAcquisitionLocation()
                + ", trainingStatus=" + getTrainingStatus()
                + ", reserved=" + getReserved()
                + ", inServiceCountry=" + getInServiceLocation() + "}";
    }
}
