import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * Data access layer for rescue animals.
 *
 * This is the only class in the application permitted to contain SQL. Driver calls these methods
 * instead of touching a database (or an in-memory list) directly, which is what lets the storage
 * mechanism change later without Driver changing at all. Every query that includes a value coming
 * from user input uses a parameterized {@link PreparedStatement} rather than concatenating that
 * value into a query string, which is what closes off SQL injection as a risk here.
 */
public class RescueAnimalDao {

    /**
     * Inserts a new animal (and its type-specific row) into the database. Returns the generated
     * animal id, or -1 if the insert did not succeed.
     */
    public int save(RescueAnimal animal) {
        String insertAnimal =
                "INSERT INTO animals (name, animal_type, gender, age, weight, acquisition_date, "
                        + "acquisition_country, training_status, reserved, in_service_country) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(insertAnimal)) {

            stmt.setString(1, animal.getName());
            stmt.setString(2, animal.getAnimalType());
            stmt.setString(3, animal.getGender());
            stmt.setString(4, animal.getAge());
            stmt.setString(5, animal.getWeight());
            stmt.setString(6, animal.getAcquisitionDate());
            stmt.setString(7, animal.getAcquisitionLocation());
            stmt.setString(8, animal.getTrainingStatus());
            stmt.setInt(9, animal.getReserved() ? 1 : 0);
            stmt.setString(10, animal.getInServiceLocation());
            stmt.executeUpdate();

            // SQLite's JDBC driver doesn't support Statement.RETURN_GENERATED_KEYS, so the
            // newly-inserted row's id is retrieved with SQLite's own last_insert_rowid() instead.
            int animalId;
            try (Statement idStmt = conn.createStatement();
                 ResultSet keys = idStmt.executeQuery("SELECT last_insert_rowid()")) {
                if (!keys.next()) {
                    return -1;
                }
                animalId = keys.getInt(1);
            }

            if (animal instanceof Dog) {
                saveDogRow(conn, animalId, (Dog) animal);
            } else if (animal instanceof Monkey) {
                saveMonkeyRow(conn, animalId, (Monkey) animal);
            }

            return animalId;

        } catch (SQLException e) {
            System.out.println("Unable to save animal: " + e.getMessage());
            return -1;
        }
    }

    private void saveDogRow(Connection conn, int animalId, Dog dog) throws SQLException {
        String insertDog = "INSERT INTO dogs (animal_id, breed) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(insertDog)) {
            stmt.setInt(1, animalId);
            stmt.setString(2, dog.getBreed());
            stmt.executeUpdate();
        }
    }

    private void saveMonkeyRow(Connection conn, int animalId, Monkey monkey) throws SQLException {
        String insertMonkey =
                "INSERT INTO monkeys (animal_id, species, breed, tail_length, height, body_length) "
                        + "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(insertMonkey)) {
            stmt.setInt(1, animalId);
            stmt.setString(2, monkey.getSpecies());
            stmt.setString(3, monkey.getBreed());
            stmt.setDouble(4, monkey.getTailLength());
            stmt.setDouble(5, monkey.getHeight());
            stmt.setDouble(6, monkey.getBodyLength());
            stmt.executeUpdate();
        }
    }

    /** Returns every dog in the database. */
    public ArrayList<Dog> findAllDogs() {
        ArrayList<Dog> dogs = new ArrayList<>();
        String query =
                "SELECT a.*, d.breed FROM animals a JOIN dogs d ON a.id = d.animal_id "
                        + "WHERE a.animal_type = 'Dog'";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                dogs.add(mapRowToDog(rs));
            }
        } catch (SQLException e) {
            System.out.println("Unable to read dogs: " + e.getMessage());
        }
        return dogs;
    }

    /** Returns every monkey in the database. */
    public ArrayList<Monkey> findAllMonkeys() {
        ArrayList<Monkey> monkeys = new ArrayList<>();
        String query =
                "SELECT a.*, m.species, m.breed, m.tail_length, m.height, m.body_length "
                        + "FROM animals a JOIN monkeys m ON a.id = m.animal_id "
                        + "WHERE a.animal_type = 'Monkey'";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                monkeys.add(mapRowToMonkey(rs));
            }
        } catch (SQLException e) {
            System.out.println("Unable to read monkeys: " + e.getMessage());
        }
        return monkeys;
    }

    /**
     * Checks whether an animal with the given name already exists (used by the intake methods
     * to reject duplicates, mirroring the in-memory check Driver used to do against its lists).
     */
    public boolean existsByName(String name) {
        String query = "SELECT 1 FROM animals WHERE name = ? COLLATE NOCASE";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            System.out.println("Unable to check for existing animal: " + e.getMessage());
            return false;
        }
    }

    /**
     * Reserves the first not-yet-reserved animal of the given type acquired in the given country.
     * Returns true if an animal was reserved, false if none matched or all matches were already
     * reserved.
     */
    public boolean reserveByTypeAndCountry(String animalType, String acquisitionCountry) {
        String selectQuery =
                "SELECT id FROM animals WHERE animal_type = ? COLLATE NOCASE "
                        + "AND acquisition_country = ? COLLATE NOCASE AND reserved = 0 LIMIT 1";
        String updateQuery = "UPDATE animals SET reserved = 1 WHERE id = ?";

        try (Connection conn = DBConnection.getConnection()) {
            int animalId;
            try (PreparedStatement selectStmt = conn.prepareStatement(selectQuery)) {
                selectStmt.setString(1, animalType);
                selectStmt.setString(2, acquisitionCountry);
                try (ResultSet rs = selectStmt.executeQuery()) {
                    if (!rs.next()) {
                        return false;
                    }
                    animalId = rs.getInt("id");
                }
            }
            try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                updateStmt.setInt(1, animalId);
                return updateStmt.executeUpdate() == 1;
            }
        } catch (SQLException e) {
            System.out.println("Unable to reserve animal: " + e.getMessage());
            return false;
        }
    }

    /** Returns every animal that is in service and not reserved, dogs and monkeys together. */
    public ArrayList<RescueAnimal> findInServiceAndUnreserved() {
        ArrayList<RescueAnimal> results = new ArrayList<>();
        results.addAll(findAllDogs());
        results.addAll(findAllMonkeys());
        results.removeIf(a -> a.getReserved() || !"in service".equalsIgnoreCase(a.getTrainingStatus()));
        return results;
    }

    private Dog mapRowToDog(ResultSet rs) throws SQLException {
        Dog dog = new Dog(
                rs.getString("name"),
                rs.getString("breed"),
                rs.getString("gender"),
                rs.getString("age"),
                rs.getString("weight"),
                rs.getString("acquisition_date"),
                rs.getString("acquisition_country"),
                rs.getString("training_status"),
                rs.getInt("reserved") == 1,
                rs.getString("in_service_country"));
        return dog;
    }

    private Monkey mapRowToMonkey(ResultSet rs) throws SQLException {
        Monkey monkey = new Monkey(
                rs.getString("name"),
                rs.getString("gender"),
                rs.getString("age"),
                rs.getString("weight"),
                rs.getString("acquisition_date"),
                rs.getString("acquisition_country"),
                rs.getString("training_status"),
                rs.getInt("reserved") == 1,
                rs.getString("in_service_country"),
                rs.getString("species"),
                rs.getString("breed"),
                rs.getDouble("tail_length"),
                rs.getDouble("height"),
                rs.getDouble("body_length"));
        return monkey;
    }
}
