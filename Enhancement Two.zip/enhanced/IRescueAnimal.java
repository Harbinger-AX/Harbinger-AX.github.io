/**
 * Defines the contract shared by every rescue animal in the system.
 *
 * Introduced as part of the software design enhancement so that {@code Driver} can work with
 * {@code Dog} and {@code Monkey} objects polymorphically through a common type, rather than
 * needing a type-specific branch for every operation. Any future animal subclass only needs to
 * implement this interface (typically by extending {@link RescueAnimal}) to be usable anywhere
 * the rest of the application expects a rescue animal.
 */
public interface IRescueAnimal {

    String getName();
    void setName(String name);

    String getAnimalType();
    void setAnimalType(String animalType);

    String getGender();
    void setGender(String gender);

    String getAge();
    void setAge(String age);

    String getWeight();
    void setWeight(String weight);

    String getAcquisitionDate();
    void setAcquisitionDate(String acquisitionDate);

    String getAcquisitionLocation();
    void setAcquisitionLocation(String acquisitionCountry);

    boolean getReserved();
    void setReserved(boolean reserved);

    String getInServiceLocation();
    void setInServiceCountry(String inServiceCountry);

    String getTrainingStatus();
    void setTrainingStatus(String trainingStatus);
}
