import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Entry point and menu logic for the Rescue Animal System.
 *
 * Database enhancement: Driver no longer holds dogList/monkeyList ArrayLists at all. Every
 * operation that used to read from or write to those in-memory lists now goes through
 * {@link RescueAnimalDao} instead, which means animal data now survives after the program exits —
 * it lives in the SQLite database built from schema.sql, not in memory. Driver has no SQL in it
 * anywhere; it only calls the DAO's methods.
 */
public class Driver {

    private static final RescueAnimalDao dao = new RescueAnimalDao();

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        char option;
        do {
            displayMenu();
            option = input.next().charAt(0);
            if (option == '1') {

                intakeNewDog(input);
            } else if (option == '2') {

                intakeNewMonkey(input);
            } else if (option == '3') {

                reserveAnimal(input);
            } else if (option == '4') {

                printAnimals('4');
            } else if (option == '5') {

                printAnimals('5');
            } else if (option == '6') {

                printAnimals('6');
            } else if (option == 'q') {

                System.out.print("You have exited the application.");
                break;
            } else {
                System.out.print("You have entered an invalid input.");
            }
        } while (option != 'q');

    }

    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }

    public static void intakeNewDog(Scanner scanner) {
        scanner.nextLine();
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        if (dao.existsByName(name)) {
            System.out.println("\n\nThis dog is already in our system\n\n");
            return; //returns to menu
        }

        System.out.println("What is the dog's breed?");
        String breed = scanner.nextLine();
        System.out.println("What is the dog's gender?");
        String gender = scanner.nextLine();
        System.out.println("What is the dog's age?");
        String age = scanner.nextLine();
        System.out.println("What is the dog's weight?");
        String weight = scanner.nextLine();
        System.out.println("When was this dog acquired?");
        String acquisitionDate = scanner.nextLine();
        System.out.println("Which country was this dog acquired?");
        String acquisitionCountry = scanner.nextLine();
        System.out.println("What is the dog's training status?");
        String trainingStatus = scanner.nextLine();
        boolean reserved = readBoolean(scanner, "Is this dog reserved? (true/false)");
        System.out.println("Which country is the dog in service?");
        String inServiceCountry = scanner.nextLine();

        Dog dog = new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry,
                trainingStatus, reserved, inServiceCountry);
        int id = dao.save(dog);
        if (id >= 0) {
            System.out.println("Your entry has been added to the dog list.");
        } else {
            System.out.println("Something went wrong saving this dog. Please try again.");
        }
    }

    public static void intakeNewMonkey(Scanner scanner) {
        scanner.nextLine();
        System.out.println("What is the monkey's name?");
        String name = scanner.nextLine();
        if (dao.existsByName(name)) {
            System.out.println("\n\nThis monkey is already in our system\n\n");
            return; //returns to menu
        }
        System.out.println("What is the monkey's gender?");
        String gender = scanner.nextLine();
        System.out.println("What is the monkey's age?");
        String age = scanner.nextLine();
        System.out.println("What is the monkey's weight?");
        String weight = scanner.nextLine();
        System.out.println("When was this monkey acquired?");
        String acquisitionDate = scanner.nextLine();
        System.out.println("Which country was this monkey acquired?");
        String acquisitionCountry = scanner.nextLine();
        System.out.println("What is the monkey's training status?");
        String trainingStatus = scanner.nextLine();
        boolean reserved = readBoolean(scanner, "Is this monkey reserved? (true/false)");
        System.out.println("Which country is the monkey in service?");
        String inServiceCountry = scanner.nextLine();
        double tailLength = readDouble(scanner, "How long is the monkey's tail (inches)?");
        double height = readDouble(scanner, "What is the monkey's height (inches)?");
        double bodyLength = readDouble(scanner, "What is the monkey's body length (inches)?");
        System.out.println("What species is the monkey?");
        String species = scanner.nextLine();
        System.out.println("What is the monkey's breed?");
        String breed = scanner.nextLine();

        Monkey monkey = new Monkey(name, gender, age, weight, acquisitionDate, acquisitionCountry,
                trainingStatus, reserved, inServiceCountry, species, breed, tailLength, height, bodyLength);
        int id = dao.save(monkey);
        if (id >= 0) {
            System.out.print("Your entry has been added to the monkey list.");
        } else {
            System.out.print("Something went wrong saving this monkey. Please try again.");
        }
    }

    public static void reserveAnimal(Scanner scanner) {
        scanner.nextLine();
        System.out.println("Enter animal type: ");
        String animalType = scanner.nextLine();
        if (animalType.equalsIgnoreCase("Monkey") || animalType.equalsIgnoreCase("Dog")) {
            System.out.println("Enter the " + animalType.toLowerCase() + "'s country of acquisition: ");
            String country = scanner.nextLine();
            boolean reserved = dao.reserveByTypeAndCountry(animalType, country);
            if (reserved) {
                System.out.println("This " + animalType.toLowerCase() + " is now reserved.");
            } else {
                System.out.println("The " + animalType.toLowerCase() + " entered is not in the list");
            }
        } else {
            System.out.println("Type not found");
        }
    }

    public static void printAnimals(char option) {
        if (option == '4') {
            System.out.println(dao.findAllDogs());
        } else if (option == '5') {
            System.out.println(dao.findAllMonkeys());
        } else if (option == '6') {
            ArrayList<RescueAnimal> available = dao.findInServiceAndUnreserved();
            for (RescueAnimal animal : available) {
                System.out.println(animal);
            }
        }
    }

    private static boolean readBoolean(Scanner scanner, String prompt) {
        while (true) {
            System.out.println(prompt);
            String responseLine = scanner.nextLine().trim();
            if (responseLine.equalsIgnoreCase("true") || responseLine.equalsIgnoreCase("yes")
                    || responseLine.equalsIgnoreCase("y")) {
                return true;
            } else if (responseLine.equalsIgnoreCase("false") || responseLine.equalsIgnoreCase("no")
                    || responseLine.equalsIgnoreCase("n")) {
                return false;
            } else {
                System.out.println("Please enter true/false (or yes/no).");
            }
        }
    }

    private static double readDouble(Scanner scanner, String prompt) {
        while (true) {
            System.out.println(prompt);
            String responseLine = scanner.nextLine().trim();
            try {
                return Double.parseDouble(responseLine);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }
}
