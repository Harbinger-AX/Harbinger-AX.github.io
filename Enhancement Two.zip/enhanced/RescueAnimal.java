/**
 * Base class for every animal tracked by the rescue system.
 *
 * Enhancements made to the original version:
 *  - All fields are now private instead of public, restoring the encapsulation the existing
 *    getters and setters were already meant to provide.
 *  - The class is now abstract and implements {@link IRescueAnimal}. A bare "rescue animal" that
 *    is neither a dog nor a monkey (nor any other concrete subtype) never made sense to
 *    instantiate on its own, so this now prevents that at compile time.
 *  - A protected, shared constructor was added so that {@code Dog} and {@code Monkey} no longer
 *    have to repeat the same nine lines of field assignment in their own constructors.
 */
public abstract class RescueAnimal implements IRescueAnimal {

    // Instance variables — private; use the accessors below rather than accessing these directly.
    private String name;
    private String animalType;
    private String gender;
    private String age;
    private String weight;
    private String acquisitionDate;
    private String acquisitionCountry;
    private String trainingStatus;
    private boolean reserved;
    private String inServiceCountry;

    /** No-argument constructor, retained for subclasses that want to build an animal field-by-field. */
    public RescueAnimal() {
    }

    /**
     * Shared constructor for the fields every rescue animal has, regardless of subtype.
     * Subclasses call this via {@code super(...)} and then set their own type-specific fields.
     */
    protected RescueAnimal(String name, String animalType, String gender, String age, String weight,
                           String acquisitionDate, String acquisitionCountry, String trainingStatus,
                           boolean reserved, String inServiceCountry) {
        this.name = name;
        this.animalType = animalType;
        this.gender = gender;
        this.age = age;
        this.weight = weight;
        this.acquisitionDate = acquisitionDate;
        this.acquisitionCountry = acquisitionCountry;
        this.trainingStatus = trainingStatus;
        this.reserved = reserved;
        this.inServiceCountry = inServiceCountry;
    }

    // Accessors and mutators

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getAnimalType() {
        return animalType;
    }

    @Override
    public void setAnimalType(String animalType) {
        this.animalType = animalType;
    }

    @Override
    public String getGender() {
        return gender;
    }

    @Override
    public void setGender(String gender) {
        this.gender = gender;
    }

    @Override
    public String getAge() {
        return age;
    }

    @Override
    public void setAge(String age) {
        this.age = age;
    }

    @Override
    public String getWeight() {
        return weight;
    }

    @Override
    public void setWeight(String weight) {
        this.weight = weight;
    }

    @Override
    public String getAcquisitionDate() {
        return acquisitionDate;
    }

    @Override
    public void setAcquisitionDate(String acquisitionDate) {
        this.acquisitionDate = acquisitionDate;
    }

    @Override
    public String getAcquisitionLocation() {
        return acquisitionCountry;
    }

    @Override
    public void setAcquisitionLocation(String acquisitionCountry) {
        this.acquisitionCountry = acquisitionCountry;
    }

    @Override
    public boolean getReserved() {
        return reserved;
    }

    @Override
    public void setReserved(boolean reserved) {
        this.reserved = reserved;
    }

    @Override
    public String getInServiceLocation() {
        return inServiceCountry;
    }

    @Override
    public void setInServiceCountry(String inServiceCountry) {
        this.inServiceCountry = inServiceCountry;
    }

    @Override
    public String getTrainingStatus() {
        return trainingStatus;
    }

    @Override
    public void setTrainingStatus(String trainingStatus) {
        this.trainingStatus = trainingStatus;
    }
}
